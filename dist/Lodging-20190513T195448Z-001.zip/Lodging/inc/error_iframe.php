<?php
echo "Site not allowed in iframe for security reasons";
?>